import java.io.*;

public class EmptyListException extends Exception{
  public void ErrorMessage(){
    System.out.println("The list is empty");
  }
}